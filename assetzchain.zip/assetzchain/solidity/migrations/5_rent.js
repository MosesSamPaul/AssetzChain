var Migrations = artifacts.require("./Rent.sol");

module.exports = function(deployer) {
  deployer.deploy(Migrations);
};
