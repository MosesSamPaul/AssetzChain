const Web3 = require('web3');
var web3 = new Web3(new Web3.providers.HttpProvider("https://ropsten.infura.io/v3/3f515a48f1d84d5bb73607d54389b693"));

//var myAddress = ""

var contractAddress = '0xbe1586d34fc174090472e75dE7e6A16A2A3179fd';

var contractABI = [
  {
    "constant": true,
    "inputs": [
      {
        "name": "",
        "type": "address"
      }
    ],
    "name": "balances",
    "outputs": [
      {
        "name": "",
        "type": "uint256"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [],
    "name": "owner",
    "outputs": [
      {
        "name": "",
        "type": "address"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "name": "",
        "type": "uint256"
      }
    ],
    "name": "items",
    "outputs": [
      {
        "name": "owner",
        "type": "address"
      },
      {
        "name": "forSale",
        "type": "bool"
      },
      {
        "name": "price",
        "type": "uint256"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "name": "index",
        "type": "uint256"
      }
    ],
    "name": "ownerChanged",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "name": "index",
        "type": "uint256"
      },
      {
        "indexed": false,
        "name": "price",
        "type": "uint256"
      }
    ],
    "name": "priceChanged",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "name": "index",
        "type": "uint256"
      },
      {
        "indexed": false,
        "name": "price",
        "type": "uint256"
      },
      {
        "indexed": false,
        "name": "forSale",
        "type": "bool"
      }
    ],
    "name": "availabilityChanged",
    "type": "event"
  },
  {
    "constant": false,
    "inputs": [
      {
        "name": "index",
        "type": "uint256"
      },
      {
        "name": "price",
        "type": "uint256"
      }
    ],
    "name": "itemForSale",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [],
    "name": "getItems",
    "outputs": [
      {
        "name": "",
        "type": "address[]"
      },
      {
        "name": "",
        "type": "bool[]"
      },
      {
        "name": "",
        "type": "uint256[]"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "name": "index",
        "type": "uint256"
      }
    ],
    "name": "buyItem",
    "outputs": [],
    "payable": true,
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [],
    "name": "withDraw",
    "outputs": [],
    "payable": true,
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [],
    "name": "destroy",
    "outputs": [],
    "payable": true,
    "stateMutability": "payable",
    "type": "function"
  }
]

var account = web3.eth.accounts.privateKeyToAccount('0x' + '1E6F35D84D9522005884EF0C6FDBDC9040E83621BDDE94D14FE22116354639CE')

web3.eth.accounts.wallet.add(account);
web3.eth.defaultAccount = account.address;
// console.log(web3.eth.defaultAccount)
// console.log(web3.eth.accounts.wallet[0]);
// console.log(web3.utils.checkAddressChecksum(web3.eth.defaultAccount));
// console.log(web3.eth.Iban.isValid(web3.eth.defaultAccount));
// console.log(web3.utils.isAddress(web3.eth.defaultAccount));
var contractInstance = new web3.eth.Contract(contractABI, contractAddress);

var privateKey = '0x1E6F35D84D9522005884EF0C6FDBDC9040E83621BDDE94D14FE22116354639CE';

function buyItem(data, callback) {
  // data = {
  console.log(data);

  console.log('heree')
  var BCdata = {};
  let obj = {
    to: contractAddress,
    data: contractInstance.methods.buyItem((data.assetId, { value: data.price, from: data.userId })),
    gas: 4700000
  }

  web3.eth.accounts.signTransaction({ obj, value: 1000000000, gas: 4700000 }, privateKey, (err, res) => {
    if (err) {
      console.log(err)
    } console.log('res', res)

    web3.eth.sendSignedTransaction(res.rawTransaction)
      .once('transactionHash', function (hash) { console.log(hash) })
      .on('error', function (error) { callback(error) })
      .then(function (receipt) {

        console.log(receipt);

        callback(BCdata);
      })
  })
}

exports.buyItem = buyItem;