var assets = require('../../models/assets');
var users = require('../../models/users');


function getassetData(assetId,InvoiceId)