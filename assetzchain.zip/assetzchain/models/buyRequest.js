var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var buyRequestSchema = new Schema(
    {
        request_id: { type: String, required: true, unique: true },
        status: { type: String },
        sellAsset: { type: Schema.Types.ObjectId, ref: 'SellAsset' },
        buyer_email: { type: String },
        buyer_contact: { type: String },
        payment: { type: String }
    }
)

module.exports = mongoose.model('BuyRequest', buyRequestSchema);
