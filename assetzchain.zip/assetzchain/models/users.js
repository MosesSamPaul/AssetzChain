var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bcrypt = require('bcrypt-nodejs');

var UserSchema = new Schema(
    {
        user_id: { type: String, required: true, unique: true },
        password: { type: String, required: true },
        email: { type: String, required: true, unique: true },
        mobile: { type: String, unique: true, required: true },
        otp: { type: String },
        address: {
            house_number: { type: String },
            street: { type: String },
            city: { type: String },
            state: { type: String }
        },
        assets: [{ type: Schema.Types.ObjectId, ref: 'Asset' }],
        public_key: { type: String }
    }
)

UserSchema.methods.validOtp = function (otp) {
    return otp === this.otp;
}

module.exports = mongoose.model('User', UserSchema);
