var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var rentRequestSchema = new Schema(
    {
        request_id: { type: String, required: true, unique: true },
        status: { type: String },
        rentAsset: { type: Schema.Types.ObjectId, ref: 'RentAsset' },
        renter_email: { type: String },
        renter_contact: { type: String },
        time: {
            from: { type: String, required: true }
        },
        date: { type: String },
        duration: { type: String },
        payment: { type: String },
        amount: { type: String },
        withdrawn: { type: String }
    }
)

module.exports = mongoose.model('RentRequest', rentRequestSchema);
