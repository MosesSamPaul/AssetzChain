var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var RentAssetSchema = new Schema(
    {
        rentAssetId: { type: String, required: true, unique: true },
        user: { type: Schema.Types.ObjectId, ref: 'User' },
        rate: { type: Number, required: true },
        availability: {
            from: { type: String, required: true },
            to: { type: String, required: true }
        },
        imageData: { type: String, required: true },
        asset: { type: Schema.Types.ObjectId, ref: 'Asset' },
        status: { type: String, required: true }
    }
)

module.exports = mongoose.model('RentAsset', RentAssetSchema);