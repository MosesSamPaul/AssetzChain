var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var assetSchema = new Schema(
    {
        nickname: { type: String, required: true },
        assetId: { type: String, required: true, unique: true },
        user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
        make: { type: String, required: true },
        //slug: { type: String },
        warranty: { type: String },
        rent: { type: String, required: true },
        request_status: { type: String },
        forSale: { type: String },
        forRent: { type: String },
        sold: { type: String },
        invoices: [
            {
                retailer: { type: String },
                date: { type: String },
                price: { type: Number },
                ocr_status: { type: Boolean, default: false },
                blockchain_status: { type: Boolean, default: false },
                multihash: { type: String },
                blockHash: { type: String },
                blockNumber: { type: String },
                contractAddress: { type: String },
                gasUsed: { type: String },
                txhash: { type: String, unique: true, sparse: true },
                invoiceType: { type: String, enum: ['INV', 'SRV', 'INS', 'WRT'] },
                added_date: {type: String}
            }
        ],
        resell: {
            current_user_id: { type: Schema.Types.ObjectId, ref: 'User' },
            price: { type: Number },
            date: { type: String },
            blockchain_status: { type: Boolean, default: false },
            blockHash: { type: String },
            blockNumber: { type: String },
            contractAddress: { type: String },
            gasUsed: { type: String },
            txHash: { type: String, unique: true, sparse: true },
        }
    }
)

module.exports = mongoose.model('Asset', assetSchema);
