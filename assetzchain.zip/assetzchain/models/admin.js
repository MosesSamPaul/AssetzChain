var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var AdminSchema = new Schema(
    {
        adminId: { type: String, required: true, unique: true },
        name: { type: String, required: true },
        phone: { type: Number, required: true },
        upi: {type: String, required: true }
    }
)

module.exports = mongoose.model('Admin', AdminSchema);