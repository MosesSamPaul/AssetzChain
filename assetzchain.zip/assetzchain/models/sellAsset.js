var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var sellAssetSchema = new Schema(
    {
        price: { type: Number },
        sellAssetId: { type: String, required: true, unique: true },
        imageData: { type: String },
        asset: { type: Schema.Types.ObjectId, ref: 'Asset' },
        user: { type: Schema.Types.ObjectId, ref: 'User' },
        status: { type: String },
        payment_status: { type: String },
        received: { type: String },
        withdrawn: { type: String }
    }
)

module.exports = mongoose.model('SellAsset', sellAssetSchema);
