const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();
const Web3 = require("web3");
var path = require('path')
var multer = require('multer');
var upload = multer();
const cookieParser = require('cookie-parser');
var ExifImage = require('exif').ExifImage;
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var expressValidator = require('express-validator');
var uuidv4 = require('uuid/v4');
var Razorpay = require('razorpay');
var fetch = require('fetch');
var request1 = require('request');
require('dotenv').config();
const sgMail = require("@sendgrid/mail");
const sapikey = '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';
sgMail.setApiKey(sapikey);

var cors = require('cors')
app.use(cors())

app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.engine('html', require('ejs').renderFile);
app.set('views', __dirname + '/views');
//app.use('/public', express.static(path.join(process.env.PWD, './assets')));
app.set('view engine', 'html');
app.use(cookieParser());
require('./modules/signup/passport');
const passport = require('passport');
app.use(passport.initialize());
app.use(passport.session())
app.use(expressValidator());
app.use(express.static(__dirname + '/assets'));
var auth = require('./modules/signup/auth.js')
var ipfs = require('./modules/ipfs/ipfs.js')
var ocr = require('./modules/ocr/ocr.js')
var gasPrice = require('./modules/web3/gas.js')
var web3 = require('./modules/web3/web3');
var buyDeal = require('./modules/web3/dealTest2.js')
var Users = require('./models/users.js');
var Assets = require('./models/assets.js');
var RentRequests = require('./models/rentRequest.js');
var RentAssets = require('./models/rentAsset.js');
var SellAssets = require('./models/sellAsset.js');
var BuyRequests = require('./models/buyRequest.js');
var Admin = require('./models/admin.js');
mongoose.connect("mongodb://har_hept:Mlab_95@ds163054.mlab.com:63054/assetzchain", { useNewUrlParser: true });
mongoose.Promise = global.Promise;
var db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error: '));

var https = require('https');
var fs = require('fs');
var options = {
    ca: fs.readFileSync('./certs/alpha_assetzchain_com.ca-bundle'),
    key: fs.readFileSync('./certs/alpha_assetzchain_com.key'),
    cert: fs.readFileSync('./certs/alpha_assetzchain_com.crt')
}
var http = require('http');
var instance = new Razorpay({
    key_id: 'rzp_test_49xSPLJGXpWUY0',
    key_secret: 'VgtqZVwUCdJiAABvJ4eyxhts'
})
//  var storage = multer.diskStorage({
//     destination: function (req, file, cb) {
//       cb(null, 'uploads/')
//     },
//     filename: function (req, file, cb) {

//       var filename = file.originalname;
//       var fileExtension = filename.split(".")[1];
//       var name = filename.split(".")[0];

//       cb(null, name + "." + fileExtension);
//     }
//   })

//var upload = multer({ storage: storage,preservePath :true });

app.get("/", function (req, res) {
    var cookie = req.cookies;
    //console.log(cookie.AssetzChain)
    jwt.verify(cookie.AssetzChain, "cipher", function (err, user) {
        if (err) {
            // console.log(err.message);
        }
        if (user) {
            res.render("homescreen.html");
        } else {
            res.render("home.html");
        }
    })
})
app.post("/sendImage", upload.single('file1'), function (req, res) {
    //    new ExifImage({image : "./uploads/sample.jpg"},function(error,exifData){
    //     if (error){
    //     console.log('Error: '+error.message);
    //     res.send(error)
    //     }
    // else{
    //     console.log(exifData.image.Model); 
    //     console.log(exifData.image.ModifyDate);
    //     res.send("File uploaded Successfully")
    // }
    //    })

    console.log(req.files);

})

app.get("/landing", function (req, res) {
    res.render("landing.html")
})

app.get("/login", function (req, res) {
    console.log("Route is /login GET")
    res.render("login.html")
})

app.get("/notifications", function (req, res) {
    res.render("notifications.html");
})

app.post("/updateslug", function (req, res) {
    //console.log(req.body);
    var assetId = req.body.assetId;
    var slug = req.body.slug;
    //var asset = new Assets({assetId:assetId});
    Assets.findById(assetId, function (err, asset) {
        //console.log(asset);
        asset.updateOne({ slug: slug }, (err, response) => {
            //console.log(res);
            res.json(response);
        });
    });
})

app.get("/adminDetails", function (req, res) {
    Admin.find(function (err, admins) {
        res.json(admins);
    })
})

app.post("/login", function (req, res) {
    console.log("Route is /login POST")
    //console.log(req.body);
    //console.log("this is here atleast")
    passport.authenticate('local', { session: false, successRedirect: '/', failureRedirect: '/' }, (err, user, info) => {
        // console.log("yes1")
        // console.log("the authenticate user: " + user)
        if (err || !user) {
            return res.status(400).json({
                status: 'error',
                user: user
            });
        }
        req.login(user, { session: false }, (err) => {
            //console.log("the login user: " + user);
            if (err) {
                let response = {
                    status: "error",
                    message: "Inavid email password"
                }
                res.send(err);
            }
            // generate a signed son web token with the contents of user object and return it in the response
            const token = jwt.sign(user.toJSON(), 'cipher', { expiresIn: "60 days" });
            res.cookie('AssetzChain', token, { maxAge: 900000000 })
            //return res.json({user, token});
            res.render("homescreen.html")
        });
    })(req, res);
})

app.get("/registration", function (req, res) {
    res.render("auth.html")
})

app.post("/registration", function (req, response) {
    var { email, mobile, pass, cpass } = req.body;
    req.check('email', "Invalid Email Address").isEmail();
    req.check('mobile', "Invalid Mobile Number").isNumeric().isLength(10);
    req.check('pass', "Passwords dont match").equals(cpass);

    var errors = req.validationErrors();
    if (errors) {
        //console.log(errors)
        response.send(errors);
        response.end();
    } else {
        auth.validateEmailAvailability(email, mobile, (valid) => {
            if (valid !== null) {
                response.send({ msg: "Email/Mobile Number already exists" });
            } else {
                var sch = new Users({
                    user_id: uuidv4(),
                    password: pass,
                    email: email,
                    mobile: mobile,
                })
                sch.save(function (err, res) {
                    if (err) {
                        console.log(err)
                        response.send(err)
                    }
                    else {
                        console.log(res)
                        var user = {
                            email: email,
                            mobile: mobile
                        }
                        auth.sendOTP(mobile);
                        const token = jwt.sign(user, 'cipher', { expiresIn: "60 days" });
                        response.cookie('AssetzChain', token, { expires: new Date(Date.now() + 1000 * 900000) })
                        response.send(
                            { msg: "success" })
                    }
                })
            }
        })
    }
})


app.get('/home', function (req, res) {
    console.log("Route is /home GET")
    res.render("homescreen.html")
})

app.get('/start', function (req, res) {
    console.log("Route is /start GET")
    res.render("home.html")
})
app.get('/otp', function (req, res) {
    res.render("otp.html");
})

// app.post('/image',upload.any(),function(req,res){
//     console.log(req.body,"image");
// })

app.post("/warrantyImage", upload.any(), function (req, res) {
    var ipfsURL = "https://gateway.ipfs.io/ipfs/";
    if (req.files == null || req.files == 'undefined') {
        response = {
            status: "error",
            message: "The file was not uploaded properly"
        }
        return res.json(response);
    } else {
        ipfs.ipfsUpload(req.files[0].buffer, (result) => {
            if (result.status == "error") {
                console.log(result, "IPFS Error");
                return res.send(result);
            } else {
                var todayDate = new Date();
                var month = todayDate.getMonth() + 1;
                var year = todayDate.getFullYear();
                var day = todayDate.getDate();
                var finalDate = day + "/" + month + "/" + year;
                var multihash = result[0].hash;
                let invoice = {
                    invoiceId: uuidv4(),
                    multihash: multihash,
                    invoiceType: 'WRT',
                    added_date: finalDate
                }
                Assets.findById(req.body.assetId, function (err, asset) {
                    asset.updateOne({ warranty: req.body.date }, function (err, updated) {
                        asset.invoices.push(invoice);
                        asset.save(function (err, result) {
                            res.json({ hash: multihash });
                        })
                    })
                })
            }
        })
    }
})

app.post('/image', upload.any(), function (req, res) {
    // console.log(req.body.name, "This is the request");
    var cookie = req.cookies;
    var user;
    //console.log(cookie.AssetzChain)
    jwt.verify(cookie.AssetzChain, "cipher", function (err, use) {
        if (err) {
            //console.log(err.message);
            res.render('auth.html');
        }
        else if (use) {
            user = use;
            //console.log(use);
        }
    })
    //console.log(req.files, "Files from form data");
    var ipfsURL = "https://gateway.ipfs.io/ipfs/"
    //console.log("it is here atleast");
    if (req.files == null || req.files == 'undefined') {
        response = {
            status: "error",
            message: "The file was not uploaded properly"
        }
        return res.json(response);
    }
    //console.log(req.files);
    ipfs.ipfsUpload(req.files[0].buffer, (result) => {
        if (result.status == "error") {
            //console.log(result, "IPFS Error");
            return res.send(result);
        } else {
            var multihash = result[0].hash;
            ocr.ocrCall(ipfsURL + result[0].hash, (result) => {
                console.log(result, "OCR result");

                if (result.status == "error") {
                    return res.send(result);
                } else {
                    var asset = new Assets(
                        {
                            nickname: req.body.name,
                            assetId: uuidv4(),
                            user_id: user._id,
                            make: result.make,
                            slug: "",
                            rent: "no",
                            request_status: ""
                        }
                    )
                    let invoice = {
                        invoiceId: uuidv4(),
                        retailer: result.retailer,
                        date: result.date,
                        price: result.amount,
                        multihash: multihash,
                        invoiceType: 'INV'
                    }
                    var invId;
                    asset.invoices.push(invoice)
                    //console.log(asset);
                    asset.save(function (err, asset) {
                        if (err) {
                            //console.log(err.errmsg)
                            let response = {
                                status: 'error',
                                error: err
                            }
                            //console.log("Response after saving to mongo", response);
                            return res.json(response);
                        }
                        //console.log("Asset saved");
                        loop:
                        for (let i = 0; i < asset.invoices.length; i++) {
                            if (asset.invoices[i].ocr_status == false) {
                                invId = asset.invoices[i]._id;
                                //console.log(invId);
                                break loop;
                            }
                        }
                        Users.findById(user._id, (err, user) => {
                            if (err) {
                                let response = {
                                    status: 'error',
                                    message: err
                                }
                                return res.json(response);
                            }
                            user.assets.push(asset._id);
                            user.save((err, result) => {
                                if (err) {
                                    let response = {
                                        status: 'error'
                                    }
                                    return res.json(response);
                                }
                                let response = {
                                    status: 'Success',
                                    asset: asset,
                                    invoiceId: invId
                                }
                                //console.log("This is the response : " + JSON.stringify(response))
                                res.json(response);
                            })
                        })
                    })
                }
            });
        }


    })
})

app.post('/validateOTP', function (req, res) {
    var cookie = req.cookies;
    //console.log(cookie.AssetzChain)
    jwt.verify(cookie.AssetzChain, "cipher", function (err, user) {
        if (err) {
            res.send(err);
        }
        auth.validateOTP(req.body.otp, user, (result) => {
            // console.log("i am here yo")
            if (result) {
                //console.log("yes");
                res.send("success");
            } else {
                res.send("success");
            }
        })
    })
})


app.get('/ocr/:assetId/:invoiceId', function (req, res) {
    res.render('ocr.html');
})

// app.get('/sell', function (req, res) {
//     res.render('http://localhost:4002/ob/profile?async=false');
// })

app.get('/ocrResults/:assetId/:invoiceId', function (req, res) {
    // console.log("fetching data");
    Assets.findById(req.params.assetId, (err, asset) => {
        if (err || !asset) {
            // console.log(err);
            let response = {
                status: 'Failed',
            }
            return res.json(response);
        }
        //console.log("its inside :" + asset);
        var inv;
        loop:
        for (let i = 0; i < asset.invoices.length; i++) {
            if (asset.invoices[i].ocr_status == false) {
                inv = asset.invoices[i];
                // console.log(inv);
                asset.invoices[i].ocr_status = true;
                asset.save();
                break loop;
            }
        }
        let response = {
            status: 'Success',
            asset: asset,
            invoice: inv
        }
        //console.log(response);
        return res.json(response)
    })
})

// app.get('/ocrResults',function(req,res){
//     let cookie = req.cookies;
//     jwt.verify(cookie.AssetzChain,"cipher",function(err,user){
//         if(err){
//             res.send(err);
//         }
//     else{
//         console.log("The search is : "+user.mobile)
//         Assets.findOne({mobile:user.mobile}),(err,result)=>{
//             console.log(result)
//             var inv;
//             loop:
//             for(let i =0;i<result.invoices.length;i++){
//                 if(result.invoices[i].ocr_status == false){
//                     inv = result.invoices[i];
//                     result.invoices[i].ocr_status = true;
//                     Assets.updateOne({mobile:user.mobile},{
//                         "invoices."
//                     })
//                     break loop;
//                 }
//             }
//             Assets.updateOne({mobile:user.mobile},{
//                 "invoices.ocr_status" : true
//            })
//             res.send(inv);

//         })
//     }})  

//     }
// )


app.get("/transaction/:assetId/:invoiceId", (req, res) => {
    console.log("yeah its here");
    res.render('transaction.html');
})

app.get("/ethResult/:assetId/:invoiceId", (req, res) => {
    var assetId = req.params.assetId;
    var invoiceId = req.params.invoiceId;
    var result = {};
    Assets.findById(assetId, (err, asset) => {
        if (err) {
            return res.json(err.errmsg);
        }
        loop:
        for (let i = 0; i < asset.invoices.length; i++) {
            if (asset.invoices[i]._id == invoiceId) {
                console.log("The invoice is : " + asset.invoices[i]);
                inv = asset.invoices[i];
                result.date = asset.invoices[i].date;
                result.blockHash = asset.invoices[i].blockHash;
                result.blockNumber = asset.invoices[i].blockNumber;
                result.transactionHash = asset.invoices[i].txhash;
                result.contract = asset.invoices[i].contractAddress;
                result.gasUsed = asset.invoices[i].gasUsed;
                asset.invoices[i].blockchain_status = true;
                //console.log(inv);
                asset.save();
                break loop;
            }
        }
        return res.json(result);
    })
    console.log("the result being sent is :" + result)
})

app.get("/save/:assetId/:invoiceId", function (req, res) {
    res.render('save.html')
})


app.post("/save/:assetId/:invoiceId", function (req, res) {
    // console.log(req.params.assetId);
    // console.log("the inv id is :" + req.params.invoiceId)
    res.redirect('/transaction/' + req.params.assetId + '/' + req.params.invoiceId);
})

// app.get("/sell",function(req,res){
//     res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4002');
//     res.json({"message":"Monika"});
//     console.log("Sending");
// })

app.get("/sell", function (req, res) {
    console.log("Sending");
    res.json({ "Name": "Monika" });
    //res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4002');
    // app.get("http://localhost:4002/ob/profile?async=false", function (req, response) {
    //     response.setHeader('Access-Control-Allow-Origin', 'http://localhost:4002');
    //res.json(response);

    // })
})

app.get("/gas", (req, res) => {
    gasPrice.getGasPrice((result) => {
        let obj = {
            message: result.gasPrice,
            txCost: result.txFee
        }
        console.log(obj);
        res.send(obj);
    });
});

//buy asset and send et"hers
app.get("/buyAsset/:sellAssetId", function (req, res) {
    console.log("Route is /buyAsset/:seelAssetId GET")
    var sellAssetId = req.params.sellAssetId;
    SellAssets.findById(sellAssetId)
        .populate({ path: 'asset', model: 'Asset' })
        .populate({ path: 'user', model: 'User' })
        .exec(function (err, sellAsset) {
            var assetId = sellAsset.asset._id;
            var price = sellAsset.price;
            var ownerPublicKey = sellAsset.user.public_key;

            var data = {
                assetId: 0,
                price: price,
                userId: ownerPublicKey
                //public_key: ownerPrivateKey
            }

            //solidity part
            buyDeal.buyItem(data, (result) => {
                console.log(JSON.stringify(result));
                res.json(result)
            })
        })
})

app.get("/buy/singleAsset/:sellAssetId/payment/success", function (req, res) {
    SellAssets.findById(req.params.sellAssetId, function (err, sellAsset) {
        sellAsset.updateOne({ payment_status: "success" }, function (err, updated) {
            res.render("./buy/confirmPayment.html")
        })
    })
})

app.get("/sold/:assetId/:sellAssetId", function (req, res) {
    SellAssets.findById(req.params.sellAssetId, function (err, sellAsset) {
        sellAsset.updateOne({ withdrawn: "yes" }, function (err, updated) {
            Assets.findById(req.params.assetId, function (err, asset) {
                asset.updateOne({ sold: "yes" }, function (err, updated) {
                    res.json(asset);
                })
            })
        })
    })
})

// app.post("/sell/withdrawEthers", function (req, res) {
//     var assetId = req.body.assetId;
//     var account_address = req.body.address;
//     SellAssets.find()
//         .populate({ path: "asset", model: "Asset" })
//         .populate({ path: "user", model: "User" })
//         .exec(function (err, sellAssets) {
//             for (let i = 0; i < sellAssets.length; i++) {
//                 if (sellAssets[i].asset._id == assetId) {
//                     var data = {
//                         address: account_address,
//                         price: sellAssets[i].price
//                     }
//                     buyDeal.withdraw(data, function (result) {
//                         console.log(result);
//                         res.json(result);
//                     })
//                 }
//             }
//         })
// })

// app.post("/sell/withdrawEthers",function(req,res){
//     var account_address = req.body.address;
//     buyDeal.withdraw()
// })

app.get("/sellAssets/:sellAssetId", function (req, res) {
    console.log(req.params.sellAssetId);
    SellAssets.findById(req.params.sellAssetId)
        .populate({
            path: 'asset', model: 'Asset'
        })
        .populate({
            path: 'user', model: 'User'
        })
        .exec(function (err, sellAsset) {
            //console.log(request, "Requesttttttttttttttt")
            res.json(sellAsset);
        })
})

app.get("/buy/sellAssets/:sellAssetId", function (req, res) {
    res.render("./buy/save.html")
})

app.post("/ownerChange", function (req, res) {
    RentRequests.findById(req.body.requestId)
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'RentAsset'
        })
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'RentAsset'
        })
        .exec(function (err, request) {
            Assets.findById(request.rentAsset.asset._id, function (err, asset) {
                asset.updateOne({
                    resell: {
                        date: new Date(),
                        blockchain_status: true,
                        blockHash: req.body.blockHash,
                        blockNumber: req.body.blockNumber,
                        gasUsed: req.body.gasUsed,
                        contractAddress: req.body.contractAddress,
                        txHash: req.body.txHash
                    }
                }, function (err, updated) {
                    res.json(updated);
                })
            })
        })

})

app.get("/addToBlockchain/:sellAssetId/:userId", function (req, res) {
    var sellAssetId = req.params.sellAssetId;
    var current_userId = req.params.userId;
    SellAssets.findById(sellAssetId)
        .populate({ path: "asset", model: "Asset" })
        .populate({ path: "user", model: "User" })
        .exec(function (err, sellAsset) {
            var asset_id = sellAsset.asset._id;
            var userId = sellAsset.user._id;
            var data = {
                user_id: current_userId,
                asset_id: asset_id,
                date: new Date(),
                act: "buy",
                price: sellAsset.price,
                desc: "phone"
            }

            web3.setDataBC1(data, (result) => {
                if (result == err) {
                    var data = {
                        status: "error",
                        message: "Couldn't add to blockchain"
                    }
                    return res.JSON(data);
                } else {
                    //console.log("We need to print this :" + result);
                    Assets.findById(asset_id, (err, asset) => {
                        if (err) {
                            return res.JSON(err.errmsg);
                        } else {
                            asset.updateOne({
                                resell: {
                                    current_user_id: current_userId,
                                    date: new Date(),
                                    blockchain_status: true,
                                    blockHash: result.blockHash,
                                    blockNumber: result.blockNumber,
                                    gasUsed: result.gasUsed,
                                    contractAddress: '0x6C7efA13e15C2BC94fF719100d29B20792c36cAe',
                                    txHash: result.transactionHash
                                }
                            }, function (err, updated) {
                                res.json(updated);
                            })
                        }
                    })
                }
            })

        })
})


app.get("/addBlockchain/:assetId/:invoiceId", (req, res) => {
    let cookie = req.cookies;
    var assetId = req.params.assetId;
    var invoiceId = req.params.invoiceId;
    jwt.verify(cookie.AssetzChain, "cipher", function (err, user) {
        if (err) {
            res.send(err);
        }
        else {
            //console.log("The search is : "+user.mobile)
            Assets.findById(assetId, (err, asset) => {
                if (err || asset == null) {
                    // console.log(err.errmsg);
                    return res.JSON(err);
                }
                // console.log(asset)
                var make = asset.make;
                var userid = asset.user_id;
                var inv;
                //res.send(result.invoice);
                loop:
                for (let i = 0; i < asset.invoices.length; i++) {
                    if (asset.invoices[i]._id == invoiceId) {
                        inv = asset.invoices[i];
                        // console.log(inv);
                        //asset.invoices[i].blockchain_status = true;
                        asset.save();
                        break loop;
                    }
                }
                data = {
                    user_id: (JSON.stringify(asset.user_id)).replace(/"/g, ''),
                    asset_id: (JSON.stringify(asset._id)).replace(/"/g, ''),
                    date: inv.date,
                    act: "buy",
                    price: inv.price,
                    desc: "phone"
                }

                // console.log("The data getting into the blockchain : " + JSON.stringify(data))

                web3.setDataBC(data, (result) => {
                    if (result == err) {
                        var data = {
                            status: "error",
                            message: "Couldn't add to blockchain"
                        }
                        return res.JSON(data);
                    }
                    // console.log("We need to print this :" + result);
                    Assets.findById(assetId, (err, asset) => {
                        if (err) {
                            return res.JSON(err.errmsg);
                        }
                        loop:
                        for (let i = 0; i < asset.invoices.length; i++) {
                            if (asset.invoices[i]._id == invoiceId) {
                                inv = asset.invoices[i];
                                asset.invoices[i].blockHash = result.blockHash;
                                asset.invoices[i].blockNumber = result.blockNumber;
                                asset.invoices[i].txhash = result.transactionHash;
                                asset.invoices[i].contractAddress = result.contract;
                                asset.invoices[i].gasUsed = result.gasUsed;
                                //asset.invoices[i].blockchain_status = true;
                                //console.log(inv);
                                asset.save();
                                break loop;
                            }
                        }

                    })
                    res.send(result);
                })
            })
        }
    })

}
)

//Updating contact address
app.post("/updateWarrantyDate", function (req, res) {
    var date = req.body.date;
    Assets.findById(req.body.assetId, function (err, asset) {
        asset.updateOne({ warranty: date }, function (err, updated) {
            res.json(asset);
        })
    })
    // Users.findById(req.body.userId, function (err, user) {
    //     user.updateOne({ public_key: address }, function (err, updated) {
    //         res.json(updated);
    //     })
    // })
})


app.get('/mobileAssets', function (req, res) {
    // console.log("Route is /mobileAssets");
    res.render('displayAssets.html');
})

app.get('/mobileAssets/accountDetails', function (req, res) {
    // console.log("Route is /mobileAssets/accountDetails GET")
    res.render("accountDetails.html");
})

app.get("/singleAsset/:assetId/success", function (req, res) {
    res.render("confirmWithdraw.html");
})

app.get('/displayAssets', function (req, res) {
    // console.log("Route is /displayAssets GET")
    let cookie = req.cookies;
    jwt.verify(cookie.AssetzChain, "cipher", function (err, user) {
        // console.log(cookie.AssetzChain, "Coockie");
        // console.log("the error is :" + err);
        //console.log(user, "User");
        // console.log(user._id, "User id");
        Users.findById(user._id, { password: false, otp: false })
            .populate({ path: 'assets', model: 'Asset' })
            .exec(function (err, user) {
                //console.log(user,"User after populating")
                if (err || !user) {
                    let response = {
                        status: 'Failed',
                        error: err
                    }
                    return res.json(response);
                }
                //console.log(user);
                // RentAssets.find(function(err,result){
                //     console.log(result);


                Users.find()
                    .populate({ path: "assets", model: "Asset" })
                    .exec(function (err, users) {
                        let response = {
                            user: user,
                            status: 'Success',
                            users: users
                        }
                        return res.json(response);
                    })
            })
    })
})

app.get('/singleAsset/:asset_id', (req, res) => {
    //console.log("This is called")
    // console.log(req.params.asset_id);
    res.render('singleAsset');
})

app.post('/singleAsset/:asset_Id', (req, res) => {
    var slug = req.body.slug;
    var assetId = req.body.assetId;
    Assets.findById(assetId, function (err, asset) {
        // console.log(asset);
        asset.updateOne({ slug: "" }, (err, response) => {
            // console.log(res);
            res.json(response);
        });
    });
})

//Send to wait
app.get("/wait", function (req, res) {
    res.render("waitForAccountId.html");
})

//Reply from assetzchain team with account id
app.get("/updateAccountId", function (req, res) {
    res.render("accountId.html");
})

//update account id to profile
app.post("/updateAccountId", function (req, res) {
    // console.log("Route is /updateAccountId POST")
    var accountId = req.body.accountId;
    var userId = req.body.userId;
    Users.findById(userId, function (err, user) {
        user.updateOne({ account_id: accountId }, function (err, updated) {
            res.json(updated);
        })
    })
})

app.post("/sendNotification", function (req, res) {
    // console.log("Route is /sendNotification")
    // console.log(req.body);
    var aname = req.body.name;
    var contact = req.body.contact;
    var anumber = req.body.anumber;
    var atype = req.body.atype;
    var ifsc = req.body.ifsc;
    var bname = req.body.bname;
    var owner_email = req.body.owner;
    //Send notification mail
    const msg = {
        to: ["monika.gs@heptagon.in", "moses@heptagon.in"],
        from: owner_email,
        subject: "AssetzChain",
        html: `
      <!DOCTYPE html>
      <html lang="en">
          <head>
            <meta charset="UTF-8">
              <title>Assetzchain</title>
              <meta name="viewport" content="width=device-width, initial-scale=1.0">   
          </head>
          <body>
              <div class="email_container">
              <i class="far fa-check-circle"></i>
                  <div class="email_box">
                      <br/>
                      <h3>Account Details:</h3>
                      <br/>
                      Linked Account Name: ${aname} <br/>
                      Contact Number: ${contact} <br/>
                      Account Number: ${anumber} <br/>
                      Account Type: ${atype} <br/>
                      IFSC: ${ifsc} <br/>
                      Beneficiary Name: ${bname} <br/>
                      <br/>
                      <br/>
                  </div>
              </div>
          </body>
      </html>
    `
    }
    sgMail.send(msg, function (err) {
        // console.log(err, "Error");
        //res.json(asset);
        res.json({ status: "success" });
    })
})

app.get("/sendEmailToAdmin/:requestId", function (req, res) {
    var requestId = req.params.requestId;
    RentRequests.findById(requestId, function (err, request) {
        var renter_email = request.renter_email;
        const msg = {
            to: ["monika.gs@heptagon.in"],
            from: renter_email,
            subject: "AssetzChain",
            html: `
      <!DOCTYPE html>
      <html lang="en">
          <head>
            <meta charset="UTF-8">
              <title>Assetzchain</title>
              <meta name="viewport" content="width=device-width, initial-scale=1.0">   
          </head>
          <body>
              <div class="email_container">
              <i class="far fa-check-circle"></i>
                  <h3>Dear Assetzchain Admin,<br/>
                  <br/>
                  
                  Renter for an asset says, he has paid the rent amount to you. Please confirm if he has paid the amount.
                  <br/>
                  <a href="https://alpha.assetzchain.com:9008/${requestId}/adminConfirm">Click here to confirm</a>
                  <br/>
                  <br/>
                  
                  Thank you</h3>
              </div>
          </body>
      </html>
    `
        }
        sgMail.send(msg, function (err) {
            // console.log(err, "Error");
            //res.json(asset);
            res.json({ status: "success" });
        })
    })
})

//Admin page
app.get("/:requestId/adminConfirm", function (req, res) {
    // console.log("Route is /:requestId/adminConfirm")
    res.render("confirmPayment.html");
})

//Payment success
app.get("/:requestId/payment/success", function (req, res) {
    var requestId = req.params.requestId;
    //res.render("");
    RentRequests.findById(req.params.requestId, function (err, request) {
        request.updateOne({ admin_status_payment: "received" }, function (err, updated) {
            const msg = {
                // to: ['akash.sunny@heptagon.in','business@heptagon.in'],
                // from: "noreply@peopledesk.co",
                to: request.renter_email,
                from: "monika.gs@heptagon.in",
                subject: "AssetzChain",
                html: `
          <!DOCTYPE html>
          <html lang="en">
              <head>
                <meta charset="UTF-8">
                  <title>Assetzchain Rent Request</title>
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
              </head>
              <body>
                  <div class="email_container">
                      <div class="email_box">
                          <h2 class="title">AssetzChain</h2>
                          <div>
                             <h3>Assetzchain admin has confirmed that you have paid rent. <br/>
                             You can go and collect the asset<h3>
                             (Please confirm once you pick the asset, you can do that in app itself or through following link)
                          </div>
                          <div>
                            <a href="https://alpha.assetzchain.com:9008/takenForRent/${requestId}/confirmReceive">Click here to view details</a>
                          </div>
                      </div>
                  </div>
              </body>
          </html>
        `
            }
            sgMail.send(msg, function (err) {
                if (!err) {
                    //console.log(err, "Error")
                    // res.json(rentAsset);
                    res.render("homescreen.html")

                } else {
                    // console.log(err);
                    res.render("homescreen.html")
                    // res.json({
                    //     status: "failed",
                    //     error: err
                    // })
                }
            });
        })
    })
})

//Payment failure
app.get("/:requestId/payment/failure", function (req, res) {
    //res.render("");
    RentRequests.findById(req.params.requestId, function (err, request) {
        request.updateOne({ admin_status_payment: "not-received" }, function (err, updated) {
            res.render("homescreen.html")
        })
    })
})

app.get('/singleAsset/:assetId/listing', (req, res) => {
    //console.log(req);
    res.render("listing");
})

app.get("/singleAsset/:assetId/listDetails", (req, res) => {
    res.render("listDetails.html");
})

//Rent asset
app.get("/singleAsset/:assetId/rent", (req, res) => {
    res.render("rentAsset1");
})

app.get("/singleAsset/:assetId/rentConfirm", function (req, res) {
    Assets.findById(req.params.assetId, function (err, asset) {
        asset.updateOne({ forRent: "yes" }, function (err, updated) {
            res.render("rentConfirm.html");
        })
    })
})

app.get("/singleAsset/:assetId/editListing", (req, res) => {
    res.render("editListing");
})

//Add details to rentAsset schema
app.post("/rentingDetails", upload.any(), (req, res) => {
    // console.log("Route is /renting Details POST")
    //Send images to ipfs
    var ipfsURL = "https://gateway.ipfs.io/ipfs/"
    // console.log(req.files, "request to rent");
    if (req.files == null || req.files == 'undefined') {
        response = {
            status: "error",
            message: "The file was not uploaded properly"
        }
        return res.json(response);
    } else {
        // console.log("Yessssssssssss");
        // console.log(req.files[0], "File from rent")
        ipfs.ipfsUpload(req.files[0].buffer, (result) => {
            if (result.status == "error") {
                //console.log("Yes error")
                // console.log(result, "Error")
                return res.send(result);
            } else {
                var multihash = result[0].hash;
                // console.log(multihash, "multihash")
                var assetId = req.body.assetId;
                var rate = req.body.rate;
                var from = req.body.from;
                var to = req.body.to;
                var hnumber = req.body.hnumber;
                var street = req.body.street;
                var city = req.body.city;
                var state = req.body.state;
                //var address = req.body.address;
                // console.log(address,"Address");
                Assets.findById(assetId, function (err, asset) {
                    // console.log(asset, "Asset");
                    var user_id = asset.user_id;
                    Users.findById(user_id, function (err, user) {

                        var rentAsset = new RentAssets(
                            {
                                rentAssetId: uuidv4(),
                                rate: rate,
                                status: "none",
                                availability: {
                                    from: from,
                                    to: to
                                },
                                imageHash: multihash
                            }
                        );
                        rentAsset["user"] = user;
                        rentAsset["asset"] = asset;
                        //rentAsset.asset.push(assetId);
                        rentAsset.save(function (err, rentAsset) {
                            if (err) {
                                // console.log(err);
                                res.json(err);
                            } else {
                                // console.log(rentAsset, "Rent Asset");
                                Assets.findById(assetId, function (err, asset) {
                                    asset.updateOne({ rent: "yes" }, (err, response) => {
                                        Users.findById(user_id, function (err, user) {
                                            // console.log(user);
                                            user.updateOne({
                                                address: {
                                                    house_number: hnumber,
                                                    street: street,
                                                    city: city,
                                                    state: state
                                                }
                                            }, function (err, updated) {
                                                console.log(err);
                                                res.json(updated);
                                            })
                                            // user["address"] = address;
                                            // user.save(function (err, user) {
                                            //     console.log(user, "Updated")
                                            //     res.render("rentConfirm");
                                            // })

                                            // user.updateOne({ address[""]: address }, function (err, response) {

                                            // })
                                        })
                                        //rentAsset["asset"] = asset;
                                        // var message = {
                                        //     asset:asset,
                                        //     rentAsset:rentAsset
                                        // }
                                    })
                                })
                            }
                        })
                    })
                })
            }
        });
    }
})

app.get("/withdrawn/:requestId", function (req, res) {
    RentRequests.findById(req.params.requestId, function (err, request) {
        request.updateOne({ withdrawn: "yes" }, function (err, updated) {
            res.json(request);
        })
    })
})

app.post("/rentingDetails1", (req, res) => {
    //console.log(req.body, "request body");
    //console.log(req.body);
    // console.log("Route is /renting Details POST")
    // //Send images to ipfs
    // console.log(req.files, "request to rent");
    // console.log("Yessssssssssss");
    //console.log(req.files[0], "File from rent")
    var assetId = req.body.assetId;
    var rate = req.body.rate;
    var from = req.body.from;
    var to = req.body.to;
    var hnumber = req.body.hnumber;
    var street = req.body.street;
    var city = req.body.city;
    var state = req.body.state;
    var imageData = req.body.imageData;

    // console.log(assetId, "Asset id")

    //var address = req.body.address;
    // console.log(address,"Address");
    Assets.findById(assetId, function (err, asset) {
        // console.log(asset, "Asset");
        var user_id = asset.user_id;
        Users.findById(user_id, function (err, user) {

            var rentAsset = new RentAssets(
                {
                    rentAssetId: uuidv4(),
                    rate: rate,
                    status: "none",
                    availability: {
                        from: from,
                        to: to
                    },
                    imageData: imageData
                }
            );
            rentAsset["user"] = user;
            rentAsset["asset"] = asset;
            //rentAsset.asset.push(assetId);
            rentAsset.save(function (err, rentAsset) {
                if (err) {
                    // console.log(err);
                    res.json(err);
                } else {
                     console.log(rentAsset, "Rent Asset");
                    Assets.findById(assetId, function (err, asset) {
                        asset.updateOne({ rent: "yes" }, (err, response) => {
                            Users.findById(user_id, function (err, user) {
                                // console.log(user);
                                user.address.house_number = hnumber;
                                user.address.street = street;
                                user.address.city = city;
                                user.address.state = state;

                                user.save(function (err, saved) {
                                    // console.log(saved);
                                    res.json(saved);
                                })
                                // user.updateOne({
                                //     address: {
                                //         house_number: hnumber,
                                //         street: street,
                                //         city: city,
                                //         state: state
                                //     }
                                // }, function (err, updated) {
                                //     console.log(err);
                                //     res.json(updated);
                                // })
                                // user["address"] = address;
                                // user.save(function (err, user) {
                                //     console.log(user, "Updated")
                                //     res.render("rentConfirm");
                                // })

                                // user.updateOne({ address[""]: address }, function (err, response) {

                                // })
                            })
                            //rentAsset["asset"] = asset;
                            // var message = {
                            //     asset:asset,
                            //     rentAsset:rentAsset
                            // }
                        })
                    })
                }
            })
        })
    })
})

//For renting
app.get("/rent/landing", function (req, res) {
    res.render("./rent/landing");
})

// app.get("/rent/:imageHash",function(req,res){
//     var hash = req.params.imageHash;
//     ipfs1.files.cat(hash,function(err,file){
//         if(err){
//             console.log(err);
//         }else{
//             var image = file.toString("base64");
//             var finaleImage = "data:image/png;base64,"+image;
//             res.json({image:finaleImage});
//         }
//     })
// })

app.get("/rent/displayAssets", function (req, res) {
    res.render("./rent/displayAssets");
})

app.get("/rent/mobileAssets", function (req, res) {
    //console.log(RentAssets,"All rent assets");
    // RentAssets.find(function (err, result) {
    //     console.log(result, "Rent assets")
    //     res.json(result);
    // })
    RentAssets.find()
        .populate({ path: 'asset', model: 'Asset' })
        .populate({ path: 'user', model: 'User' })
        .exec(function (err, rentAsset) {
            res.json(rentAsset);
        })
});

app.get("/buy/mobileAssets", function (req, res) {
    SellAssets.find()
        .populate({ path: 'asset', model: 'Asset' })
        .populate({ path: 'user', model: 'User' })
        .exec(function (err, sellAssets) {
            res.json(sellAssets);
        })
})

app.get("/rent/singleAsset/:rentAssetId", function (req, res) {
    res.render("./rent/rentAsset.html")
})

// app.get("/rent/user/:user_id", function (req, res) {
//     var user_id = req.params.user_id;
//     Users.findById(user_id,function(err,user){
//         res.json(user);
//     })
// })

app.get("/rent/userDetails/:user_id", function (req, res) {
    Users.findById(req.params.user_id, function (err, user) {
        // console.log(user);
        res.json(user);
    })
})

app.get("/rent/singleAsset/:rentAssetId/rentDetails", function (req, res) {
    res.render("./rent/rentDetails.html")
})

app.post("/rent/singleAsset/:rentAssetId/rentDetails/request", function (req, res) {
    // console.log("Route is /rent/singleAsset/:rentAssetId/rentDetails/request POST")
    var status = req.body.status;
    var assetId = req.body.assetId;
    var name = req.body.name;
    var email = req.body.email;
    var contact = req.body.contact;
    var userId = req.body.userId;
    var rentAssetId = req.body.rentAssetId;
    var from = req.body.from;
    var date = req.body.date;
    var duration = req.body.duration;
    var amount = req.body.amount;
    RentAssets.findById(rentAssetId, function (err, rentAsset) {
        rentAsset.updateOne({ status: status }, (err, response) => {
            RentAssets.findById(rentAssetId)
                .populate({ path: "user", model: "User" })
                .exec(function (err, rentAsset1) {
                    var userEmail = rentAsset1.user.email;
                    //console.log(userEmail, "User email");
                    //})

                    //Users.findById(userId, function (err, user) {
                    //RentAssets.findById(rentAssetId, function (err, rentedAsset) {
                    var rentRequest = new RentRequests({
                        request_id: uuidv4(),
                        status: status,
                        renter_email: email,
                        renter_contact: contact,
                        time: {
                            from: from
                        },
                        date: date,
                        duration: duration,
                        payment: "pending",
                        amount: amount
                    })
                    //rentRequest["owner"] = user;
                    rentRequest["rentAsset"] = rentAsset;
                    rentRequest.save(function (err, response) {
                        //console.log(response);
                        var requestId = response._id;
                        var assetNickName = response.rentAsset.asset.nickname;
                        var assetName = response.rentAsset.asset.make;
                        // rentAsset.updateOne({ request_id: response._id }, function (err, updatedRentAsset) {

                        //Send a mail to owner to accept the request
                        const msg = {
                            // to: ['akash.sunny@heptagon.in','business@heptagon.in'],
                            // from: "noreply@peopledesk.co",
                            to: userEmail,
                            from: response.renter_email,
                            subject: "AssetzChain",
                            html: `
                      <!DOCTYPE html>
                      <html lang="en">
                          <head>
                            <meta charset="UTF-8">
                              <title>Assetzchain Rent Request</title>
                              <meta name="viewport" content="width=device-width, initial-scale=1.0">
                          </head>
                          <body>
                              <div class="email_container">
                                  <div class="email_box">
                                      <h2 class="title">AssetzChain</h2>
                                      <div>
                                         <h3>Your asset has been requested by a person for rent.<h3>
                                      </div>
                                      <div>
                                        <a href="https://alpha.assetzchain.com:9008/rented/${requestId}/confirm">Click here to view details</a>
                                      </div>
                                  </div>
                              </div>
                          </body>
                      </html>
                    `
                        }
                        sgMail.send(msg, function (err) {
                            if (!err) {
                                console.log(err, "Error")
                                res.json(rentAsset);
                            } else {
                                console.log(err);
                                res.json({
                                    status: "failed",
                                    error: err
                                })
                            }
                        });
                    })
                })
        })
    })
})

//accept or reject request
app.get("/rented/:requestId/confirm", function (req, res) {
    res.render("./rented/confirmAccept")
})

app.get("/rent/singleAsset/:rentAssetId/rentDetails/request", function (req, res) {
    res.render("./rent/requestmsg.html")
})

//rented
app.get("/rented/rentedAssets", function (req, res) {
    res.render("./rented/rented.html")
})

app.get("/rented/displayAssets", function (req, res) {
    res.render("./rented/displayAssets.html")
})

//confirm receive
app.get("/rented/:id/confirmReceive", function (req, res) {
    res.render("./rented/confirmReceive.html")
})

//confirm return
app.get("/rented/:id/confirmReturn", function (req, res) {
    res.render("./rented/confirmReturn.html")
})

//received confirmation Yes
app.get("/rented/receivedYes/:requestId/receive", function (req, res) {
    var requestId = req.params.requestId;
    RentRequests.findById(requestId, function (err, request) {
        request.updateOne({ status: "received" }, function (err, updated) {
            res.render("./rented/displayAssets")
        })
    })
})

//returned yes
app.get("/rented/returnedYes/:requestId/return", function (req, res) {
    var requestId = req.params.requestId;
    // RentRequests.findById(requestId, function (err, request) {
    RentRequests.findById(req.params.requestId)//, function (err, request) {
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'RentAsset'
        })
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'RentAsset'
        }).exec(function (err, request) {
            // var renter_email = request.renter_email;
            // var owner_email = request.rentAsset.user.email;
            var renter_email = request.renter_email;
            var owner_email = request.rentAsset.user.email;
            // })
            //Send mail to renter
            const msg = {
                to: renter_email,
                from: owner_email,
                subject: "AssetzChain",
                html: `
              <!DOCTYPE html>
              <html lang="en">
                  <head>
                    <meta charset="UTF-8">
                      <title>Assetzchain</title>
                      <meta name="viewport" content="width=device-width, initial-scale=1.0">   
                  </head>
                  <body>
                      <div class="email_container">
                      <i class="far fa-check-circle"></i>
                          <div class="email_box">
                              <br/>
                              <h4>Owner says you have returned the asset back to him. please click the below link for more details</h4>
                              <br/>
                              <br/>
                              <a href="https://alpha.assetzchain.com:9008/takenForRent/${requestId}/confirmReturn">https://alpha.assetzchain.com/takenForRent/${requestId}/confirmReturn"></a>
                          </div>
                      </div>
                  </body>
              </html>
            `
            }
            sgMail.send(msg, function (err) {
                //res.json(asset);
                res.render("./rented/displayAssets");
            })
            // RentRequests.findById(requestId, function (err, request) {
            //     request.updateOne({ status: "returned" }, function (err, updated) {
            //         //transfer amount to owner
            //         res.render("./rented/displayAssets")
            //     })
        })
})

app.get("/rented/responseAccept/:assetId/:email/:requestId", function (req, res) {
    var requestId = req.params.requestId;
    var email = req.params.email;
    // console.log(req.params, "Parameters");
    //Assets.findById(req.params.assetId, function (err, asset) {
    //asset.updateOne({ request_status: "accepted" }, (err, response) => {
    //console.log(response);
    RentRequests.findById(req.params.requestId)
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'RentAsset'
        })
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'RentAsset'
        }).exec(function (err, request) {
            var renter_email = request.renter_email;
            var owner_email = request.rentAsset.user.email;
            request.updateOne({ status: "accepted" }, function (err, updated) {
                //send confirmation mail to renter
                const msg = {
                    to: renter_email,
                    from: owner_email,
                    subject: "AssetzChain",
                    html: `
                              <!DOCTYPE html>
                              <html lang="en">
                                  <head>
                                    <meta charset="UTF-8">
                                      <title>Assetzchain Rent Request</title>
                                      <meta name="viewport" content="width=device-width, initial-scale=1.0">   
                                  </head>
                                  <body>
                                      <div class="email_container">
                                      <i class="far fa-check-circle"></i>
                                          <div class="email_box">
                                              <h5 class="title">Congrats!!!!</h5>
                                              <br/>
                                              Your rent request has been confirmed!
                                              <br/>
                                              Click on below link for more details
                                              <br/>
                                              <a href="https://alpha.assetzchain.com:9008/takenForRent/${requestId}/confirm">Click here to go to assetzchain</a>
                                          </div>
                                      </div>
                                  </body>
                              </html>
                            `
                }
                sgMail.send(msg, function (err) {
                    res.json(request);
                    //res.render("./rented/displayAssets")
                });
            });
        })
    //})
    //})
})

//Rent request confirmation
app.get("/takenForRent/:requestId/confirm", function (req, res) {
    // RentRequests.findById(req.params.requestId, function (err, request) {
    //     request.updateOne({ payment: "success" }, function (err, updated) {
    res.render("./takenForRent/confirmAccept.html");
    //     })
    // })
})

app.get("/rented/responseReject/:requestId", function (req, res) {
    //console.log(req.params, "Parameters");
    RentRequests.findById(req.params.requestId, function (err, request) {
        request.updateOne({ status: "rejected" }, (err, response) => {
            // console.log(response);
            res.render("./rented/displayAssets")
        });
    })
})

//get all rent requests
app.get("/rented/rentRequests", function (req, res) {
    RentRequests.find()
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'asset', model: 'Asset'
            },
            model: 'RentAsset'
        }).populate({
            path: 'rentAsset',
            populate: {
                path: 'user', model: 'User'
            },
            model: 'RentAsset'
        })
        .exec(function (err, requests) {
            if (err) {
                res.json(err);
            }
            res.json(requests);
        })
})

//get only one request
app.get("/rented/singleAsset/:requestId", function (req, res) {
    console.log("Route is /rented/singleAsset/:requestId GET")
    RentRequests.findById(req.params.requestId)
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'RentAsset'
        })
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'RentAsset'
        })
        .exec(function (err, request) {
            res.json(request);
        })
})

//For buying
app.get("/buy/landing", function (req, res) {
    res.render("./buy/landing");
})

//Get sell assets
app.get("/buy/sellAssets/", function (req, res) {
    // console.log("Route is /all/sellAssets GET")
    SellAssets.find()
        .populate({ path: 'asset', model: 'Asset' })
        .populate({ path: 'user', model: 'User' })
        .exec(function (err, sellAssets) {
            res.json(sellAssets);
        })
})

app.get("/buy/displayAssets", function (req, res) {
    res.render("./buy/displayAssets");
})

app.get("/buy/singleAsset/:assetId", function (req, res) {
    res.render("./buy/buyDetails.html")
})

app.get("/buy/mobileAssets/:sellAssetId", function (req, res) {
    //res.render("./buy/buyDetails.html")
    SellAssets.findById(req.params.sellAssetId)
        .populate({ path: "asset", model: 'Asset' })
        .populate({ path: "user", model: "User" })
        .exec(function (err, sellAsset) {
            res.json(sellAsset);
        })
})

app.post("/buy/singleAsset/buyRequest", function (req, res) {
    var sellAssetId = req.body.sellAssetId;
    var buyer_email = req.body.email;
    var buyer_contact = req.body.contact;
    SellAssets.findById(sellAssetId, function (err, sellAsset) {
        sellAsset.updateOne({ status: "requested" }, function (err, updated) {
            SellAssets.findById(sellAssetId)
                .populate({ path: "asset", model: "Asset" })
                .populate({ path: "user", model: "User" })
                .exec(function (err, sellAsset) {
                    var buyRequest = new BuyRequests({
                        request_id: uuidv4(),
                        status: "requested",
                        buyer_email: buyer_email,
                        buyer_contact: buyer_contact
                    });
                    buyRequest["sellAsset"] = sellAsset;
                    buyRequest.save(function (err, buyRequest) {
                        res.json(buyRequest);
                    })
                })
        })
    })
})

//To list bought assets
app.get("/buy/boughtAssets", function (req, res) {
    res.render("./buy/boughtAssets.html");
})

//confirm receive
app.post("/buy/receivedYes/receive", function (req, res) {
    var sellAssetId = req.body.sellAssetId;
    var buyer_id = req.body.user_id;
    SellAssets.findById(sellAssetId)
        .populate({ path: "asset", model: "Asset" })
        .populate({ path: "user", model: "User" })
        .exec(function (err, sellAsset) {
            var assetId = sellAsset.asset._id;
            var user_id = sellAsset.user._id;
            var asset_id = sellAsset.asset._id;
            sellAsset.updateOne({ received: "yes" }, function (err, updated) {
                Assets.findById(assetId, function (err, asset) {
                    asset.updateOne({ sold: "yes" }, function (err, updated) {
                        asset.updateOne({
                            resell: {
                                current_user_id: buyer_id
                            }
                        }, function (err, updated) {
                            Users.findById(buyer_id, function (err, user) {
                                user.assets.push(sellAsset.asset._id);
                                user.save(function (err, result) {
                                    res.json(sellAsset)
                                })
                            })
                        })
                    })
                })
            })
        })
})

app.get("/buy/:sellAssetId/transaction", function (req, res) {
    res.render("./buy/transaction.html");
})

app.get("/sellAssets/:sellAssetId", function (req, res) {
    SellAssets.findById(req.params.sellAssetId)
        .populate({ path: 'asset', model: 'Asset' })
        .populate({ path: 'user', model: 'User' })
        .exec(function (err, sellAsset) {
            res.json(sellAsset)
        })
})

app.get("/buy/receivedYes/:sellAssetId/purchase", function (req, res) {
    res.render("./buy/purchase.html");
})

app.get("/buy/boughtAssets/all", function (req, res) {
    // BuyRequests.find(function (err, requests) {
    //     res.json(requests);
    // })
    BuyRequests.find()
        .populate({
            path: 'sellAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'SellAsset'
        })
        .populate({
            path: 'SellAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'SellAsset'
        })
        .exec(function (err, requests) {
            //console.log(request, "Requesttttttttttttttt")
            res.json(requests);
        })

})

app.get("/buy/boughtAssets/:buyRequestId/confirmReceive", function (req, res) {
    res.render("./buy/confirmReceive.html");
})

app.get("/buy/singleAsset/:sellAssetId/payment", function (req, res) {
    res.render("./buy/payment.html")
})

app.get("/buy/singleAsset/:sellAssetId/makePayment", function (req, res) {
    res.render("./buy/payment2.html")
})

//buy confirm page
app.get("/buy/:buyRequestId/confirm", function (req, res) {
    res.render("./sell/confirmAccept.html")
})

app.get("/buy/:buyRequestId", function (req, res) {
    BuyRequests.findById(req.params.buyRequestId)
        .populate({
            path: 'sellAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'SellAsset'
        })
        .populate({
            path: 'sellAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'SellAsset'
        })
        .exec(function (err, request) {
            res.json(request);
        })
})

app.get("/buy/boughtAssets/:buyRequestId", function (req, res) {
    BuyRequests.findById(req.params.buyRequestId)
        .populate({
            path: 'sellAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'SellAsset'
        })
        .populate({
            path: 'sellAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'SellAsset'
        }).exec(function (err, request) {
            res.json(request)
        })
})

//Accept request
app.get("/buy/responseAccept/:assetId/:email/:buyRequestId", function (req, res) {
    var buyRequestId = req.params.requestId;
    var email = req.params.email;
    //console.log(req.params, "Parameters");
    Assets.findById(req.params.assetId, function (err, asset) {
        asset.updateOne({ status: "accepted" }, (err, response) => {
            // console.log(response);
            BuyRequests.findById(req.params.buyRequestId)//, function (err, request) {
                .populate({
                    path: 'sellAsset',
                    populate: {
                        path: 'asset', model: 'Asset'
                    }, model: 'SellAsset'
                })
                .populate({
                    path: 'sellAsset',
                    populate: {
                        path: 'user', model: 'User'
                    }, model: 'SellAsset'
                }).exec(function (err, request) {
                    var buyer_email = request.buyer_email;
                    var owner_email = request.sellAsset.user.email;
                    request.updateOne({ status: "accepted" }, function (err, updated) {
                        //send confirmation mail to renter
                        const msg = {
                            to: buyer_email,
                            from: owner_email,
                            subject: "AssetzChain",
                            html: `
                                  <!DOCTYPE html>
                                  <html lang="en">
                                      <head>
                                        <meta charset="UTF-8">
                                          <title>Assetzchain Rent Request</title>
                                          <meta name="viewport" content="width=device-width, initial-scale=1.0">   
                                      </head>
                                      <body>
                                          <div class="email_container">
                                          <i class="far fa-check-circle"></i>
                                              <div class="email_box">
                                                  <h5 class="title">Congrats!!!!</h5>
                                                  <br/>
                                                  Your buy request has been confirmed!
                                                  <br/>
                                                  Click on below link for more details
                                                  <br/>
                                                  <a href="https://alpha.assetzchain.com:9008/buy/${requestId}/payment">Click here to go to assetzchain</a>
                                              </div>
                                          </div>
                                      </body>
                                  </html>
                                `
                        }
                        sgMail.send(msg, function (err) {
                            res.json(asset);
                            //res.render("./rented/displayAssets")
                        });
                    });
                })
        })
    })
})

// app.get("/buy/:buyRequestId/payment", function (req, res) {
//     res.render("./buy/payment.html");
// })

//RazorPay
app.post("/rent/razorpay", function (req, res) {
    //console.log(req.body);
    console.log("Route is /rent/razorpay")
    //res.render("./buy/landing");
    //RazorPay
    var amount = req.body.amount;
    var requestId = req.body.requestId;
    //console.log(amount, "Amount")

    var options = {
        amount: amount,
        currency: "INR",
        receipt: "order_rcptid_12",
        payment_capture: '0'
    }

    instance.orders.create(options, function (err, order) {
        //console.log(order, "Order");
        RentRequests.findById(requestId, function (err, request) {
            request.updateOne({ order_id: order.id }, function (err, updated) {
                var message = {
                    key: "rzp_test_49xSPLJGXpWUY0",
                    order: order
                }
                res.json(message);
            })
        })
    });
});

//Taken for rent
app.get("/takenForRent/displayAssets", function (req, res) {
    res.render('./takenForRent/displayAssets');
})

app.post("/takenForRent/razorpay", function (req, res) {
    var payment_id = req.body.paymentId;
    var requestId = req.body.requestId;
    var amount = req.body.amount;
    RentRequests.findById(requestId, function (err, request) {
        request.updateOne({ payment_id: payment_id, amount: amount }, function (err, updated) {
            res.json({ status: "success" });
        })
    })
})

//Yes received
app.get("/takenForRent/receivedYes/:requestId/receive", function (req, res) {
    var requestId = req.params.requestId;
    RentRequests.findById(req.params.requestId)//, function (err, request) {
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'RentAsset'
        })
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'RentAsset'
        }).exec(function (err, request) {
            var renter_email = request.renter_email;
            var owner_email = request.rentAsset.user.email;
            //send a mail to owner
            const msg = {
                to: owner_email,
                from: renter_email,
                subject: "AssetzChain",
                html: `
              <!DOCTYPE html>
              <html lang="en">
                  <head>
                    <meta charset="UTF-8">
                      <title>Assetzchain</title>
                      <meta name="viewport" content="width=device-width, initial-scale=1.0">   
                      <style>
                            .font{
                                font-size: 20px;
                            }
                          </style>
                  </head>
                  <body>
                      <div class="email_container">
                      <i class="far fa-check-circle"></i>
                          <div class="font">
                              <br/>
                              <h6>Renter says he has received the asset. please click the below link for more details</h6>
                              <br/>
                              <br/>
                              <a href="https://alpha.assetzchain.com:9008/rented/${requestId}/confirmReceive">https://alpha.assetzchain.com:9008/rented/${requestId}/confirmReceive"></a>
                          </div>
                      </div>
                  </body>
              </html>
            `
            }
            sgMail.send(msg, function (err) {
                res.render("./takenForRent/displayAssets")
            })
        })
})

//Received No
app.get("/takenForRent/receivedNo/:requestId", function (req, res) {
    var requestId = req.params.requestId;
    RentRequests.findById(requestId, function (err, request) {
        request.updateOne({ receive_status: "not_received" }, function (err, updated) {
            res.render("./takenForRent/displayAssets")
        })
    })
})

app.get("/takenForRent/returnedYes/:requestId/return", function (req, res) {
    var requestId = req.params.requestId;
    //console.log(requestId);
    //RentRequests.findById(requestId, function (err, request) {
    RentRequests.findById(requestId)//, function (err, request) {
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'RentAsset'
        })
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'RentAsset'
        }).exec(function (err, request) {
            //console.log(request, "Request")
            request.updateOne({ status: "returned" }, function (err, updated) {
                res.render("./takenForRent/displayAssets")
            })
        })
})

//Yes returned
/*app.get("/takenForRent/returnedYes/:requestId/return", function (req, res) {
    var requestId = req.params.requestId;
    //console.log(requestId);
    //RentRequests.findById(requestId, function (err, request) {
    RentRequests.findById(requestId)//, function (err, request) {
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'asset', model: 'Asset'
            }, model: 'RentAsset'
        })
        .populate({
            path: 'rentAsset',
            populate: {
                path: 'user', model: 'User'
            }, model: 'RentAsset'
        }).exec(function (err, request) {
            //console.log(request, "Request")
            request.updateOne({ status: "returned" }, function (err, updated) {
                //var orderId = request.order_id;
                var owner_email = request.rentAsset.user.email;
                var owner_phone = request.rentAsset.user.mobile;
                var renter_email = request.renter_email;
                const msg = {
                    to: ["monika.gs@heptagon.in"],
                    from: renter_email,
                    subject: "AssetzChain",
                    html: `
                  <!DOCTYPE html>
                  <html lang="en">
                      <head>
                        <meta charset="UTF-8">
                          <title>Assetzchain</title>
                          <meta name="viewport" content="width=device-width, initial-scale=1.0">   
                          <style>
                            .font{
                                font-size: 20px;
                            }
                          </style>
                      </head>
                      <body>
                          <div class="email_container">
                          <i class="far fa-check-circle"></i>
                              <div class="email_box">
                                  <br/>
                                  <div class="font">
                                  Renter confirmed that he has returned the asset back to its owner.
                                  <br/>
                                  <br/>
                                  Please transfer the rent amount to the owner</h6>
                                  <br/>
                                  Owner Details<br/>
                                  Phone: ${owner_phone},
                                  <br/>
                                  Email: ${owner_email}
                                  <br/>
                                  </div>
                                  (Copy the above phone number)
                                  <br/>
                                  <br/>
                              </div>
                          </div>
                      </body>
                  </html>
                `
                }
                sgMail.send(msg, function (err) {
                    //RentRequests.findByIdAndDelete(requestId, function (err, response) {
                        res.render("./takenForRent/displayAssets")
                    //})
                    // res.json(asset);
                })
                //res.json(request);
            })
        })
})*/

app.get("/takenForRent/:requestId/confirmReceive", function (req, res) {
    res.render('./takenForRent/confirmReceive');
})

app.get("/takenForRent/:requestId/confirmReturn", function (req, res) {
    res.render("./takenForRent/confirmReturn");
})

app.get("/takenForRent/:requestId/makePayment", function (req, res) {
    res.render("./takenForRent/makePayment");
})

//Payment confirmation
app.get("/takenForRent/:requestId/confirmPayment", function (req, res) {
    RentRequests.findById(req.params.requestId, function (err, request) {
        request.updateOne({ payment: "success" }, function (err, updated) {
            res.render("./takenForRent/confirmPayment");
        })
    })
})

//Sell routes
app.get("/singleAsset/:assetId/sell", function (req, res) {
    res.render("sellAsset.html");
})

app.post("/sellingDetails", function (req, res) {
    //console.log(req.body)
    var imageData = req.body.imageData;
    var price = req.body.price;
    var assetId = req.body.assetId;
    //var account_address = req.body.account_address;
    var house_number = req.body.address.house_number;
    var street = req.body.address.street;
    var city = req.body.address.city;
    var state = req.body.address.state;
    Assets.findById(assetId, function (err, asset) {
        var user_id = asset.user_id;
        asset.updateOne({ forSale: "yes" }, function (err, updated) {
            Users.findById(user_id, function (err, user) {
                //console.log(user, "Got user")
                user.address.house_number = house_number;
                user.address.street = street;
                user.address.city = city;
                user.address.state = state;

                //console.log(user,"After saving")
                //console.log(house_number, street, city, state)
                user.save(function (err, result) {
                    // console.log(result)
                    var sellAsset = new SellAssets({
                        sellAssetId: uuidv4(),
                        price: price,
                        imageData: imageData
                    });
                    sellAsset["asset"] = asset;
                    sellAsset["user"] = user;
                    sellAsset.save(function (err, sellAsset) {
                        Users.findById(user_id, function (err, user) {
                            // console.log(user);
                            res.json(sellAsset);
                        })

                    })
                })
            })
        })
    })
})

//purchase
app.get("/purchase", function (req, res) {
    res.render("./buy/purchase.html");
})

app.get("/singleAsset/:assetId/sellConfirm", function (req, res) {
    res.render("sellConfirm.html");
})

app.get("/routes", function (req, res) {
    var routes = [];
    app._router.stack.forEach(function (r) {

        if (r.route && r.route.path) {
            //console.log(r.route.path);
            //res.json({routes: r.route.path});
            routes.push(r.route.path);
        }
    })
    setTimeout(function () {
        res.json(routes);
        //console.log(routes)
    }, 3000);
})

// app.listen(9000, function () {
//     console.log("Listening to 9000");
// });

app.set('port', 9008);
var server = https.createServer(options, app)
var httpPort = 9007;
var httpApp = express();
var httpRouter = express.Router();
httpApp.use('*', httpRouter);
httpRouter.get('*', function (req, res) {
    var host = req.get('Host');
    host = host.replace(/:\d+$/, ":" + app.get('port'));
    var destination = ['https://', host, req.url].join('');
    return res.redirect(destination);
})

var httpServer = http.createServer(httpApp);
httpServer.listen(httpPort);

server.listen(9008,function(){
    console.log("Started at port 9008");
});

// server.on('error',onError);
// server.on('listening',onListening);